// SettradeSdkWrapper.cpp
#include "SettradeWrapper.h"

#include<iostream>

using namespace std;

SettradeSdkWrapper::SettradeSdkWrapper() : m_sdkDll(nullptr) {
}

SettradeSdkWrapper::~SettradeSdkWrapper() {
    Uninitialize();
}

bool SettradeSdkWrapper::Initialize() {
    m_sdkDll = LoadLibrary(L"SettradeInterfaceCPPV2.dll");
    if (!m_sdkDll) {
        return false;
    }

    m_iCreateContext = reinterpret_cast<iCreateContext>(GetProcAddress(m_sdkDll, "iCreateContext"));
    //m_fCreateContext = reinterpret_cast<iCreateContext>(GetProcAddress(m_sdkDll, "iCreateContext"));

    return true;
}

void SettradeSdkWrapper::Uninitialize() {
    if (m_sdkDll) {
        FreeLibrary(m_sdkDll);
        m_sdkDll = nullptr;
    }
}

bool SettradeSdkWrapper::CreateContext()
{
    m_iCreateContext(&v1, "S", "S", "S", "S", "S", "S", "S", 1, 1, 10);
    return true;
}

