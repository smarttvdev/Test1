#pragma once

#include <Windows.h>
#include <string>

#include "ExternDll.h"


class SettradeSdkWrapper {
public:
    SettradeSdkWrapper();
    ~SettradeSdkWrapper();

    bool Initialize();
    void Uninitialize();

    // Wrapper functions for SDK calls
    bool CreateContext();
    int GetAccountInfo(std::string& accountInfo);
    double GetCurrentPrice(const std::string& symbol);
    // Add more wrapper functions as needed

private:
    HMODULE m_sdkDll;

    iCreateContext m_iCreateContext;
    CreateContext_return v1;

    // Function pointers for SDK calls
    //iCreateContext      m_fCreateContext;
    // Add more function pointers as needed
};